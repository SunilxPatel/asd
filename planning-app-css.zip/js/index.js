/* CREDIT: https://dribbble.com/shots/3001561-Qplanning-App 

I recreated the Rifayet Uday mockup in Html/Css.

Beatiful design btw
*/