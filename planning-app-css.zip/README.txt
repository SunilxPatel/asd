A Pen created at CodePen.io. You can find this one at http://codepen.io/simoberny/pen/gLMjBj.

 Partially working planning app, only CSS. 
Design by https://dribbble.com/shots/3001561-Qplanning-App.

